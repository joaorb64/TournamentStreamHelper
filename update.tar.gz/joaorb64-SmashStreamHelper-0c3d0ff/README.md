# SmashStreamHelper

- Install Python 3.X and be sure to have it added to "Path" when installing
- `python -m pip install -r requirements.txt`
- `python AjudanteDeStream.pyw` or double click it

[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/W7W22YK26)
